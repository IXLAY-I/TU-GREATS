-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for tugreats
CREATE DATABASE IF NOT EXISTS `tugreats` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `tugreats`;

-- Dumping structure for table tugreats.examresult
CREATE TABLE IF NOT EXISTS `examresult` (
  `Result_number` text DEFAULT NULL,
  `ID` text DEFAULT NULL,
  `date` text DEFAULT NULL,
  `Expiration date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.examresult: ~0 rows (approximately)

-- Dumping structure for table tugreats.forums
CREATE TABLE IF NOT EXISTS `forums` (
  `ForumID` text DEFAULT NULL,
  `ID` text DEFAULT NULL,
  `text` text DEFAULT NULL,
  `answer` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.forums: ~0 rows (approximately)

-- Dumping structure for table tugreats.q&a
CREATE TABLE IF NOT EXISTS `q&a` (
  `Question` text DEFAULT NULL,
  `Answer` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.q&a: ~0 rows (approximately)

-- Dumping structure for table tugreats.register
CREATE TABLE IF NOT EXISTS `register` (
  `Register_number` int(11) NOT NULL AUTO_INCREMENT,
  `ID` text DEFAULT NULL,
  `Examcenter` text DEFAULT NULL,
  `Date` text DEFAULT NULL,
  `Time` text DEFAULT NULL,
  `Coupon` enum('true','false') DEFAULT NULL,
  `Createat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Register_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.register: ~1 rows (approximately)
INSERT INTO `register` (`Register_number`, `ID`, `Examcenter`, `Date`, `Time`, `Coupon`, `Createat`) VALUES
	(1, '6610742303', 'รังสิต', '08/09/2567', '09:00 - 12:00 น.', 'false', '2024-09-08 02:14:14');

-- Dumping structure for table tugreats.teamleader
CREATE TABLE IF NOT EXISTS `teamleader` (
  `score_id` text DEFAULT NULL,
  `Result_number` text DEFAULT NULL,
  `L` text DEFAULT NULL,
  `M` text DEFAULT NULL,
  `Exempt` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.teamleader: ~0 rows (approximately)

-- Dumping structure for table tugreats.tu100
CREATE TABLE IF NOT EXISTS `tu100` (
  `score_id` text DEFAULT NULL,
  `Result_number` text DEFAULT NULL,
  `D` text DEFAULT NULL,
  `V` text DEFAULT NULL,
  `G` text DEFAULT NULL,
  `Exempt` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.tu100: ~0 rows (approximately)

-- Dumping structure for table tugreats.tu101
CREATE TABLE IF NOT EXISTS `tu101` (
  `score_id` text DEFAULT NULL,
  `Result_number` text DEFAULT NULL,
  `H` text DEFAULT NULL,
  `Z` text DEFAULT NULL,
  `Y` text DEFAULT NULL,
  `C` text DEFAULT NULL,
  `T` text DEFAULT NULL,
  `Exempt` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.tu101: ~0 rows (approximately)

-- Dumping structure for table tugreats.tu102
CREATE TABLE IF NOT EXISTS `tu102` (
  `score_id` text DEFAULT NULL,
  `Result_number` text DEFAULT NULL,
  `U` text DEFAULT NULL,
  `A` text DEFAULT NULL,
  `P` text DEFAULT NULL,
  `Exempt` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.tu102: ~0 rows (approximately)

-- Dumping structure for table tugreats.tu103
CREATE TABLE IF NOT EXISTS `tu103` (
  `score_id` text DEFAULT NULL,
  `Result_number` text DEFAULT NULL,
  `I` text DEFAULT NULL,
  `S` text DEFAULT NULL,
  `O` text DEFAULT NULL,
  `Exempt` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.tu103: ~0 rows (approximately)

-- Dumping structure for table tugreats.tu106
CREATE TABLE IF NOT EXISTS `tu106` (
  `score_id` text DEFAULT NULL,
  `Result_number` text DEFAULT NULL,
  `R` text DEFAULT NULL,
  `B` text DEFAULT NULL,
  `W` text DEFAULT NULL,
  `E` text DEFAULT NULL,
  `Exempt` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.tu106: ~0 rows (approximately)

-- Dumping structure for table tugreats.users
CREATE TABLE IF NOT EXISTS `users` (
  `ID` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `password` text DEFAULT NULL,
  `Coupon` enum('true','false') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table tugreats.users: ~0 rows (approximately)
INSERT INTO `users` (`ID`, `name`, `password`, `Coupon`) VALUES
	('6610742303', 'ธนวัฒน์ ภาคาพรต', '123', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;

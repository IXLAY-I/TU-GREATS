const buttonDate = document.querySelectorAll('.btnDate');
const buttonTime = document.querySelectorAll('.btnTime');
const buttonCoupon = document.querySelectorAll('.btnCoupon');

let lastActiveButtonDate = null;
let lastActiveButtonTime = null;
let lastActiveButtonCoupon = null;

buttonDate.forEach(button => {
    button.addEventListener('click', () => {
        if (lastActiveButtonDate && lastActiveButtonDate !== button) {
            lastActiveButtonDate.classList.remove('active');
        }

        if (lastActiveButtonDate === button) {
            button.classList.remove('active');
            lastActiveButtonDate = null;
        } else {
            button.classList.add('active');
            lastActiveButtonDate = button;
        }
    });
});

buttonTime.forEach(button => {
    button.addEventListener('click', () => {
        if (lastActiveButtonTime && lastActiveButtonTime !== button) {
            lastActiveButtonTime.classList.remove('active');
        }

        if (lastActiveButtonTime === button) {
            button.classList.remove('active');
            lastActiveButtonTime = null;
        } else {
            button.classList.add('active');
            lastActiveButtonTime = button;
        }
    });
});

buttonCoupon.forEach(button => {
    button.addEventListener('click', () => {
        if (lastActiveButtonCoupon && lastActiveButtonCoupon !== button) {
            lastActiveButtonCoupon.classList.remove('active');
        }

        if (lastActiveButtonCoupon === button) {
            button.classList.remove('active');
            lastActiveButtonCoupon = null;
        } else {
            button.classList.add('active');
            lastActiveButtonCoupon = button;
        }
    });
});
const mysql = require('mysql2')
const express = require('express')
const app = express()
const port = 3000
var cors = require('cors')
var bodyParser = require('body-parser')

var conection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "tugreats"
});

con = conection.promise();
conection.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});

app.use(cors())
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.post('/users/login', async (req, res) => {
    let ID = req.body.ID
    let password = req.body.password
    try {
        const [login] = await con.query(`select * from users where ID = '${ID}' and password = '${password}'`)
        res.status(201).json({
            message: "Successful"

        })
    } catch (error) {
        res.status(401).json({
            message: "Error"
        })
    }
})

app.post('/users', async (req, res) => {
    let ID = req.body.ID
    try {
        const [data] = await con.query(`select * from users where ID = '${ID}'`)
        res.status(201).json({
            message: "Successful",
            StudentID: data[0].ID,
            name: data[0].name
        })
    } catch (error) {
        res.status(401).json({
            message: "Error"
        })
    }
})

app.post('/users/register', async (req, res) => {
    let ID = req.body.ID
    let Examcenter = req.body.Examcenter
    let Date = req.body.Date
    let Time = req.body.Time
    let Coupon = req.body.Coupon
    try {
        const [AddData] = await con.query(`insert into register (ID, Examcenter, Date, Time, Coupon) VALUE ('${ID}', '${Examcenter}', '${Date}', '${Time}', '${Coupon}')`)
        res.status(201).json({
            message: "Successful"
        })
    } catch (error) {
        res.status(401).json({
            message: "Error"
        })
    }
})

app.post('/users/forums', async (req, res) => {
    let ID = req.body.ID
    let Text = req.body.Text
    try {
        const [data] = await con.query(`select ForumID from forums`)
        let existingIDs = data.map(row => row.ForumID);
        while (true) { 
            let ForumID = Math.floor(Math.random() * 1000000) + 1
            console.log(ForumID);
            if (!existingIDs.includes(String(ForumID))) {
                const [AddForums] = await con.query(`insert into forums (ForumID, ID, text, answer, likes) VALUE ('${ForumID}', '${ID}', '${Text}', ${0}, ${0})`)
                res.status(201).json({
                    message: "Successful"
                })
                break;
            }
        }
    } catch (error) {
        res.status(401).json({
            message: "Error"
        })
    }
})

app.post('/users/ForumLike', async (req, res) => {
    let ForumID = req.body.ForumID
    try {
        const [ForumLikeData] = await con.query(`select likes from forums where ForumID = '${ForumID}'`)
        let AddLike = ForumLikeData[0].likes + 1
        await con.query(`update forums set likes = ${AddLike} where ForumID = '${ForumID}'`)
        res.status(201).json({
            message: "Successful"
        })
    } catch (error) {
        res.status(401).json({
            message: "Error"
        })
    }
})

app.post('/users/show_forums', (req, res) => {
    conection.query(`select text, answer, likes from forums`, function (error, results, fields) {
        try {
            res.status(201).json({
                message: "Successful",
                data: results
            })
        }
        catch (error) {
            res.status(401).json({
                message: "Error"
            }, 401)
        }
    });
})

// app.post('/users/create_room', (req, res) => {
//     let user_id = req.body.user_id
//     let room_id = Math.floor(Math.random() * 10000)
//     let room_bot_id = Math.floor(Math.random() * 10000)
//     let room_user_id = Math.floor(Math.random() * 10000)
//     let room_name = req.body.room_name
//     let password = req.body.password
//     try {
//         conection.query(`insert into room (room_id, name, people, password) VALUE ('${room_id}', '${room_name}', ${1}, '${password}')`);
//         conection.query(`insert into room_user (room_user_id, user_id, room_id, result_point, bet, chair, bot) VALUE ('${room_bot_id}', '${0}', '${room_id}', ${0}, ${0}, ${0}, ${true})`);
//         conection.query(`insert into room_user (room_user_id, user_id, room_id, result_point, bet, chair, bot) VALUE ('${room_user_id}', '${user_id}', '${room_id}', ${0}, ${0}, ${0}, ${false})`);
//         if (password == "") {
//             res.status(201).json({
//                 message: "Successful",
//                 room_id: room_id,
//                 room_bot_id: room_bot_id,
//                 room_user_id: room_user_id,
//                 password: "none",
//                 people: 1
//             }) 
//         } else {
//             res.status(201).json({
//                 message: "Successful",
//                 room_id: room_id,
//                 room_bot_id: room_bot_id,
//                 room_user_id: room_user_id,
//                 password: password,
//                 people: 1
//             }) 
//         }
//     }
//     catch {
//         res.status(401).json({
//             message: "Error"
//         }, 401)
//     }
// })

// app.post('/users/join_room', (req, res) => {
//     let user_id = req.body.user_id
//     let room_id = req.body.room_id
//     let password = req.body.password
//     conection.query(`select * from room where room_id = '${room_id}'`, function (error, results_room, fields) {
//         let room_user_id = Math.floor(Math.random() * 10000)
//         if (results_room[0].people < 5) {
//             if (results_room[0].password == "") {
//                 try {
//                     conection.query(`insert into room_user (room_user_id, user_id, room_id, result_point, bet, chair, bot) VALUE ('${room_user_id}', '${user_id}', '${results_room[0].room_id}', ${0}, ${0}, ${0}, ${false})`);
//                     let people = parseInt(results_room[0].people) + 1
//                     conection.query(`update room set people = ${people} where room_id = '${room_id}'`)
//                     res.status(200).json({
//                         message: "Successful",
//                         room_user_id: room_user_id
//                     })
//                 }
//                 catch (error) {
//                     res.status(401).json({
//                         message: "Error"
//                     }, 401)
//                 }
//             } else {
//                 if (password == results_room[0].password) {
//                     try {
//                         conection.query(`insert into room_user (room_user_id, user_id, room_id, result_point, bet, chair, bot) VALUE ('${room_user_id}', '${user_id}', '${results_room[0].room_id}', ${0}, ${0}, ${0}, ${false})`);
//                         let people = parseInt(results_room[0].people) + 1
//                         conection.query(`update room set people = ${people} where room_id = '${room_id}'`)
//                         res.status(200).json({
//                             message: "Successful"
//                         })
//                     }
//                     catch (error) {
//                         res.status(401).json({
//                             message: "Error"
//                         }, 401)
//                     }
//                 } else {
//                     res.status(404).json({
//                         massage: "Incorrect password."
//                     }, 404)
//                 }
//             }
//         } else {
//             res.status(401).json({
//                 message: "The number of people in the room had reached its maximum."
//             }, 401)
//         }
//     })
// })

// app.post('/users/winner', async (req, res) => {
//     let room_id = req.body.room_id
//     const [results_room] = await con.query(`select * from room_user where room_id = '${room_id}'`)
//     try {
//         let room_point = []
//         for (let index = 0; index < results_room.length; index++) {
//             room_point.push(results_room[index].result_point)
//         }
//         let max_point = Math.max(...room_point)
//         const [winner] = await con.query(`select user_id, room_id, result_point, chair from room_user where room_id = '${room_id}' and result_point = ${max_point}`)
//         let all = `SELECT room_user.chair, room_user_card.card_id from room_user_card LEFT JOIN room_user ON room_user.room_user_id = room_user_card.room_user_id WHERE room_user.room_id = '${room_id}'`
//         let sql = `SELECT room_user.chair, room_user_card.card_id from room_user_card LEFT JOIN room_user ON room_user.room_user_id = room_user_card.room_user_id WHERE room_user.result_point = ${max_point} and room_user.room_id = '${room_id}'`
//         conection.query(sql, function (err, winner_card) {
//             conection.query(all, function (error, all_card) {
//                 res.status(200).json({
//                     message: "Successful",
//                     winner: winner,
//                     all_card: all_card,
//                     winner_card: winner_card
//                 })
//             })
//         })
//     } catch (error) {
//         res.status(401).json({
//             message: "Error"
//         })
//     }
// })

// app.post('/users/finish', async (req, res) => {
//     let room_id = req.body.room_id
//     level = [0, 10, 50, 100, 200, 300, 500, 700, 1000, 1500, 3000]
//     try {
//         const [results_room] = await con.query(`select * from room_user where room_id = '${room_id}'`)
//         for (let i = 0; i < results_room.length; i++) {
//             if (results_room[i].bet >= 1) {
//                 if (results_room[0].result_point < results_room[i].result_point) {
//                     if (results_room[i].user_id != 0) {
//                         const [results_winner] = await con.query(`select money, round, round_win, exp from users where user_id = '${results_room[i].user_id}'`)
//                         let plus_money = parseInt(results_room[i].bet * 1.75);
//                         let added_money = plus_money + parseInt(results_winner[0].money);
//                         let plus_round_win = parseInt(results_winner[0].round_win) + 1;
//                         let plus_winrate = (plus_round_win / parseInt(results_winner[0].round) * 100);
//                         let plus_exp = parseInt(results_winner[0].exp) + 10;
//                         conection.query(`update users set round_win = ${plus_round_win} where user_id = '${results_room[i].user_id}'`);
//                         conection.query(`update users set money = ${added_money} where user_id = '${results_room[i].user_id}'`);
//                         conection.query(`update users set winrate = ${plus_winrate} where user_id = '${results_room[i].user_id}'`);
//                         conection.query(`update users set exp = ${plus_exp} where user_id = '${results_room[i].user_id}'`);
//                     } else {
//                         continue;
//                     }
//                 } else if (results_room[0].result_point ==  results_room[i].result_point) {
//                     if (results_room[i].user_id != 0) {
//                         const [results_same] = await con.query(`select money, round, round_win, exp from users where user_id = '${results_room[i].user_id}'`)
//                         let added_money = parseInt(results_room[i].bet) + parseInt(results_same[0].money);
//                         let plus_exp = parseInt(results_same[0].exp) + 5;
//                         let plus_winrate = (parseInt(results_same[0].round_win) / parseInt(results_same[0].round) * 100);
//                         conection.query(`update users set money = ${added_money} where user_id = '${results_room[i].user_id}'`);
//                         conection.query(`update users set winrate = ${plus_winrate} where user_id = '${results_room[i].user_id}'`);
//                         conection.query(`update users set exp = ${plus_exp} where user_id = '${results_room[i].user_id}'`);
//                     } else {
//                         continue;
//                     }
//                 } else {
//                     if (results_room[i].user_id != 0) {
//                         const [results_winrate] = await con.query(`select round, round_win, exp from users where user_id = '${results_room[i].user_id}'`)
//                         let plus_winrate = (parseInt(results_winrate[0].round_win) / parseInt(results_winrate[0].round) * 100);
//                         conection.query(`update users set winrate = ${plus_winrate} where user_id = '${results_room[i].user_id}'`);
//                     } else {
//                         continue;
//                     }
//                 }
//                 for (let index = 0; index < level.length; index++) {
//                     if (results_room[i].user_id != 0) {
//                         const [select_level] = await con.query(`select exp, level from users where user_id = '${results_room[i].user_id}'`);
//                         if (index + 1 <= level.length) {
//                             if (select_level[0].exp > level[index + 1] && index == select_level[0].level) {
//                                 let up_level = parseInt(select_level[0].level) + 1
//                                 conection.query(`update users set level = ${up_level} where user_id = '${results_room[i].user_id}'`);
//                                 break;
//                             }
//                         }
//                     }
//                 }
//             }
//         }
//         conection.query(`delete from room_user_card where room_id = '${room_id}'`)
//         function sleep(ms) {
//             return new Promise(resolve => setTimeout(resolve, ms));
//         }
//         async function main() {
//             await sleep(1000);
//             conection.query(`update room_user set result_point = ${0}, bet = ${0} where room_id = '${room_id}'`);
//             conection.query(`select username, money from users`, function (error, results_data, fields) {
//                 res.status(201).json({
//                     message: "Successful"
//                 })
//             })
//         }
//         main();
//     }
//     catch (error) {
//         res.status(401).json({
//             message: "Error"
//         })
//     }
// })

// app.post('/users/exit', async (req, res) => {
//     let user_id = req.body.user_id
//     let room_id = req.body.room_id
//     const [results_room] = await con.query(`select * from room_user where room_id = '${room_id}'`)
//     try {
//         if (results_room.length <= 2) {
//             conection.query(`delete from room_user where user_id = '${user_id}'`)
//             conection.query(`delete from room_user where user_id = '${0}' and room_id = '${room_id}'`)
//             conection.query(`delete from room where room_id = '${room_id}'`)
//             res.status(200).json({
//                 message: "Successful"
//             })
//         } else {
//             const [results_people] = await con.query(`select people from room where room_id = '${room_id}'`)
//             let remove_people = parseInt(results_people[0].people) - 1
//             conection.query(`update room set people = ${remove_people} where room_id = '${room_id}'`);
//             conection.query(`delete from room_user where user_id = '${user_id}'`)
//             res.status(200).json({
//                 message: "Successful"
//             })
//         }
//     } catch (error) {
//         res.status(401).json({
//             message: "Error"
//         })
//     }
// })

app.listen(port, () => {
    console.log(`Example app listening on port 1${port}`)
})
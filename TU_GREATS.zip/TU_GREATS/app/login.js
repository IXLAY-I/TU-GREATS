const LoginMenu = document.querySelector('#LoginMenu')
const Login = document.querySelector('#Login')
const CloseLogin = document.querySelector('#CloseLogin')
const LoginMenuScore = document.querySelector('#LoginMenuScore')
const LoginScore = document.querySelector('#LoginScore')
const CloseLoginScore = document.querySelector('#CloseLoginScore')

LoginMenu.addEventListener('click', () => {
    Login.classList.toggle('hidelogin')
})

LoginMenuScore.addEventListener('click', () => {
    LoginScore.classList.toggle('hidelogin')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== LoginMenu) {
        Login.classList.add('hidelogin')
    }
})

document.addEventListener('click', e => {
    if (!CloseLoginScore.contains(e.target) && e.target !== LoginMenuScore) {
        LoginScore.classList.add('hidelogin')
    }
})

////////////////////////////////////////////////////////////

const SeeMoreInformation = document.querySelector('#SeeMoreInformation')
const Information = document.querySelector('#Information')

SeeMoreInformation.addEventListener('click', () => {
    Information.classList.toggle('hideInformation')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== SeeMoreInformation) {
        Information.classList.add('hideInformation')
    }
})

////////////////////////////////////////////////////////////

const SeeMoreRuleHee = document.querySelector('#SeeMoreRuleHee')
const RuleHee = document.querySelector('#RuleHee')

SeeMoreRuleHee.addEventListener('click', () => {
    RuleHee.classList.toggle('hideRuleHee')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== SeeMoreRuleHee) {
        RuleHee.classList.add('hideRuleHee')
    }
})

////////////////////////////////////////////////////////////

const SeeMoreWhatIsGreats = document.querySelector('#SeeMoreWhatIsGreats')
const WhatIsGreats = document.querySelector('#WhatIsGreats')

SeeMoreWhatIsGreats.addEventListener('click', () => {
    WhatIsGreats.classList.toggle('hideWhatIsGreats')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== SeeMoreWhatIsGreats) {
        WhatIsGreats.classList.add('hideWhatIsGreats')
    }
})
const setting = document.querySelector('#dropdownmenu');
const menu = document.querySelector('#menu');

setting.addEventListener('click', () => {
    menu.classList.toggle('hidemenu')
})

document.addEventListener('click', e => {
    if (!menu.contains(e.target) && e.target !== setting) {
        menu.classList.add('hidemenu')
    }
})

////////////////////////////////////////////////////////////

const LoginMenu = document.querySelector('#LoginMenu')
const Login = document.querySelector('#Login')
const CloseLogin = document.querySelector('#CloseLogin')

LoginMenu.addEventListener('click', () => {
    Login.classList.toggle('hidelogin')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== LoginMenu) {
        Login.classList.add('hidelogin')
    }
})

////////////////////////////////////////////////////////////

const SeeMoreInformation = document.querySelector('#SeeMoreInformation')
const Information = document.querySelector('#Information')

SeeMoreInformation.addEventListener('click', () => {
    Information.classList.toggle('hideInformation')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== SeeMoreInformation) {
        Information.classList.add('hideInformation')
    }
})

////////////////////////////////////////////////////////////

const SeeMoreRuleHee = document.querySelector('#SeeMoreRuleHee')
const RuleHee = document.querySelector('#RuleHee')

SeeMoreRuleHee.addEventListener('click', () => {
    RuleHee.classList.toggle('hideRuleHee')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== SeeMoreRuleHee) {
        RuleHee.classList.add('hideRuleHee')
    }
})

////////////////////////////////////////////////////////////

const SeeMoreWhatIsGreats = document.querySelector('#SeeMoreWhatIsGreats')
const WhatIsGreats = document.querySelector('#WhatIsGreats')

SeeMoreWhatIsGreats.addEventListener('click', () => {
    WhatIsGreats.classList.toggle('hideWhatIsGreats')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== SeeMoreWhatIsGreats) {
        WhatIsGreats.classList.add('hideWhatIsGreats')
    }
})
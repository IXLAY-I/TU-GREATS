const LoginMenu = document.querySelector('#LoginMenu')
const Login = document.querySelector('#Login')
const CloseLogin = document.querySelector('#CloseLogin')
const LoginMenuScore = document.querySelector('#LoginMenuScore')
const LoginScore = document.querySelector('#LoginScore')
const CloseLoginScore = document.querySelector('#CloseLoginScore')
const LoginMenuQa = document.querySelector('#LoginMenuQa')
const LoginQa = document.querySelector('#LoginQa')
const CloseLoginQa = document.querySelector('#CloseLoginQa')
const LoginMenuForum = document.querySelector('#LoginMenuForum')
const LoginForum = document.querySelector('#LoginForum')
const CloseLoginForum = document.querySelector('#CloseLoginForum')
const LoginMenuMaxScreen = document.querySelector('#LoginMenuMaxScreen')
const LoginMaxScreen = document.querySelector('#LoginMaxScreen')
const CloseLoginMaxScreen = document.querySelector('#CloseLoginMaxScreen')

LoginMenu.addEventListener('click', () => {
    Login.classList.toggle('hidelogin')
    hideSidebar();
})

LoginMenuScore.addEventListener('click', () => {
    LoginScore.classList.toggle('hidelogin')
    hideSidebar();
})

LoginMenuQa.addEventListener('click', () => {
    LoginQa.classList.toggle('hidelogin')
    hideSidebar();
})

LoginMenuForum.addEventListener('click', () => {
    LoginForum.classList.toggle('hidelogin')
    hideSidebar();
})

LoginMenuMaxScreen.addEventListener('click', () => {
    LoginMaxScreen.classList.toggle('hidelogin')
    hideSidebar();
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== LoginMenu) {
        Login.classList.add('hidelogin')
    }
})

document.addEventListener('click', e => {
    if (!CloseLoginScore.contains(e.target) && e.target !== LoginMenuScore) {
        LoginScore.classList.add('hidelogin')
    }
})

document.addEventListener('click', e => {
    if (!CloseLoginQa.contains(e.target) && e.target !== LoginMenuQa) {
        LoginQa.classList.add('hidelogin')
    }
})

document.addEventListener('click', e => {
    if (!CloseLoginForum.contains(e.target) && e.target !== LoginMenuForum) {
        LoginForum.classList.add('hidelogin')
    }
})

document.addEventListener('click', e => {
    if (!CloseLoginMaxScreen.contains(e.target) && e.target !== LoginMenuMaxScreen) {
        LoginMaxScreen.classList.add('hidelogin')
    }
})

////////////////////////////////////////////////////////////

const SeeMoreInformation = document.querySelector('#SeeMoreInformation')
const Information = document.querySelector('#Information')

SeeMoreInformation.addEventListener('click', () => {
    Information.classList.toggle('hideInformation')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== SeeMoreInformation) {
        Information.classList.add('hideInformation')
    }
})

////////////////////////////////////////////////////////////

const SeeMoreRuleHee = document.querySelector('#SeeMoreRuleHee')
const RuleHee = document.querySelector('#RuleHee')

SeeMoreRuleHee.addEventListener('click', () => {
    RuleHee.classList.toggle('hideRuleHee')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== SeeMoreRuleHee) {
        RuleHee.classList.add('hideRuleHee')
    }
})

////////////////////////////////////////////////////////////

const SeeMoreWhatIsGreats = document.querySelector('#SeeMoreWhatIsGreats')
const WhatIsGreats = document.querySelector('#WhatIsGreats')

SeeMoreWhatIsGreats.addEventListener('click', () => {
    WhatIsGreats.classList.toggle('hideWhatIsGreats')
})

document.addEventListener('click', e => {
    if (!CloseLogin.contains(e.target) && e.target !== SeeMoreWhatIsGreats) {
        WhatIsGreats.classList.add('hideWhatIsGreats')
    }
})

function showSidebar(){
    const sidebar = document.querySelector('.sidebar')
    sidebar.style.display = "flex"
}

function hideSidebar(){
    const sidebar = document.querySelector('.sidebar')
    sidebar.style.display = "none"
}

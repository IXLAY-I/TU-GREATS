// const countdownBtn = document.getElementById('countdownBtn');
// const countdownDisplay = document.getElementById('countdownDisplay');
// const countdownText = document.getElementById('countdownText');

// // กำหนดวันที่และเวลาที่ต้องการเปิดใช้งานปุ่ม
// const targetDate = new Date('2024-09-22T18:21:30');

// function updateCountdown() {
//   const currentDate = new Date();
//   const timeDiff = targetDate - currentDate;

//   if (timeDiff > 0) {
//     const seconds = Math.floor((timeDiff / 1000) % 60);
//     const minutes = Math.floor((timeDiff / 1000 / 60) % 60);
//     const hours = Math.floor((timeDiff / (1000 * 60 * 60)) % 24);
//     const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
//     countdownText.textContent = 'ระบบยังไม่เปิดให้สมัครสอบกรุณารอ';
//     countdownDisplay.textContent = `${days} วัน ${hours} ชั่วโมง ${minutes} นาที ${seconds}`;
//   } else {
//     countdownBtn.disabled = false;
//     clearInterval(interval);
//   }
// }

// const interval = setInterval(updateCountdown, 1000);

// countdownBtn.addEventListener('click', startCountdown);